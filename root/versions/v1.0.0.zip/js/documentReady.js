import $ from 'jquery';
import emblemScrollHelper from './emblemScrollHelper.js';


var documentReady = {
	ready: function() {
		//start the stuff necessary to do when the document has been loaded
		const widthToSet = $(document.documentElement).outerWidth();
		$('#page').css({'width': widthToSet + 'px'});
		emblemScrollHelper.addEventListeners();
	}
}

module.exports = documentReady;
