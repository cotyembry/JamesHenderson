/*
*		   Author:  John Coty Embry
*	 Date Created:  8/9/16
*	Last Modified:  8/11/16
*
*	Proverbs 3:5-6 (one of my favorites, go check it out)
*/

import documentReady from './documentReady.js';
import React from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery';

import Emblem from './components/Emblem.jsx';
import Header from './components/Header.jsx';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';

$(document).ready(function() {
	documentReady.ready();
});

ReactDOM.render(<Emblem />, document.getElementById('emblem'));
ReactDOM.render(<Header />, document.getElementById('header'));
ReactDOM.render(<Navbar />, document.getElementById('navbar'));
ReactDOM.render(<Footer />, document.getElementById('footer'));
