var emblemScrollHelper = {
	addEventListeners: function() {
		document.getElementsByTagName('body')[0].addEventListener('scroll', function() {
			alert('hello');
		})
	}
}

module.exports = emblemScrollHelper;
