/*
*		   Author:  	John Coty Embry
*	Last Modified:  	08/11/2016
*	 Date Created:  	08/09/2016
*/

import React from 'react';
import $ from 'jquery';

//todo: make the nav bars change colors for a few seconds when tapped on to make the website more touchscreen friendly

var Navbar = React.createClass({
	render: function() {
		return ( 
			<div id="parent-navbar-item" style={parentNavbar}>
				<div id="1-navbar-item"  style={navbarItem.one}></div>
				<div id="2-navbar-item"  style={navbarItem.one}></div>
				<div id="3-navbar-item"  style={navbarItem.one}></div>
				<div id="4-navbar-item"  style={navbarItem.one}></div>
				<div id="5-navbar-item"  style={navbarItem.one}></div>
				<div id="6-navbar-item"  style={navbarItem.one}></div>
				<div id="7-navbar-item"  style={navbarItem.one}></div>
			</div>
		)
	}
});
/*
*	todo: write a utility function that will convert back and forth
*	between percentages and pixels
*/
var parentNavbar = {
	//I'm going to assume that the browser is above - I suppose - 500px in width?? (apparently 1024 is the average number, so I'll try my best to include tablets)
	width: '100%',
	height: '35px',
	background: 'orange'
}
var navbarItem = {
	get one() {
		var widthTS = (($(document.documentElement).outerWidth() * 0.80) / 7) + 'px';
		return {
			width: widthTS,
			height: '100%',
			borderRight: 'solid 1px brown',
			boxSizing: 'border-box'
		}
	}
}

var lastChild = {
	width: (100/7) + '%',
	height: '100%'
}

// var divStyle = {
//   color: 'white',
//   backgroundImage: 'url(' + imgUrl + ')',
//   WebkitTransition: 'all', // note the capital 'W' here
//   msTransition: 'all' // 'ms' is the only lowercase vendor prefix
// };

// ReactDOM.render(<div style={divStyle}>Hello World!</div>, mountNode);

module.exports = Navbar;
