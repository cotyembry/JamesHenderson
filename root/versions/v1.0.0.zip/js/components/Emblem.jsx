import React from 'react';

//document.addEventListener('scroll', EmblemObject.pageDidScroll)

var Emblem = React.createClass({
	render: function() {
		return (
			<div id="emblem-element" style={styles}></div>
		)
	}
});

var styles = {
	width: '150%',
	height: '70px',
	position: 'fixed',
	top: '0px',
	left: '-25%',
	background: '#511515',

}

var EmblemObject = {
	//hasScrolled will help me initialize the scrolling starting value
	hasScrolled: false,
	scrollPosition: 0,
	pageDidScroll: function(e) {
		if(EmblemObject.hasScrolled === false) {
			EmblemObject.hasScrolled = true;
			EmblemObject.scrollPosition = document.documentElement.scrollTop;
		}
		console.log(e);
	}
}

module.exports = Emblem;