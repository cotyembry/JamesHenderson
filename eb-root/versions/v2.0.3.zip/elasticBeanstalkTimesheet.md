started t2.micro instance: Mon Jan  10:40pm 2017
